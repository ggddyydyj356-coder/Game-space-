package com.gamespace.app

import android.content.Context

/** Game shuru hone par settings badalta hai aur baad mein purani settings wapas laata hai. */
object GameMode {

    private val keys = listOf(
        "global:zen_mode",
        "global:heads_up_notifications_enabled",
        "global:window_animation_scale",
        "global:transition_animation_scale",
        "global:animator_duration_scale",
        "system:screen_brightness_mode"
    )

    private fun even(x: Int): Int = (x / 2) * 2

    fun apply(ctx: Context) {
        val p = ctx.getSharedPreferences("gs", Context.MODE_PRIVATE)

        // Purani values ek baar save karo
        if (!p.getBoolean("active", false)) {
            val e = p.edit()
            for (k in keys) {
                val parts = k.split(":")
                e.putString("saved_$k", Shell.run("settings get ${parts[0]} ${parts[1]}").trim())
            }
            e.putBoolean("active", true)
            e.commit()
        }

        if (p.getBoolean("dnd", true)) {
            Shell.run("settings put global zen_mode 1")
        }
        if (p.getBoolean("heads", true)) {
            Shell.run("settings put global heads_up_notifications_enabled 0")
        }
        if (p.getBoolean("anim", true)) {
            Shell.run("settings put global window_animation_scale 0.5")
            Shell.run("settings put global transition_animation_scale 0.5")
            Shell.run("settings put global animator_duration_scale 0.5")
        }
        if (p.getBoolean("bright", true)) {
            Shell.run("settings put system screen_brightness_mode 0")
        }
        if (p.getBoolean("ram", true)) {
            Shell.run("am kill-all")
        }

        val scale = p.getInt("res", 100)
        if (scale < 100 && !p.getBoolean("wm_applied", false)) {
            val sz = Shell.run("wm size")
            val dn = Shell.run("wm density")
            val sm = Regex("Physical size: (\\d+)x(\\d+)").find(sz)
            val dm = Regex("Physical density: (\\d+)").find(dn)
            if (sm != null && dm != null) {
                val w = even(sm.groupValues[1].toInt() * scale / 100)
                val h = even(sm.groupValues[2].toInt() * scale / 100)
                val d = dm.groupValues[1].toInt() * scale / 100
                Shell.run("wm size ${w}x$h")
                Shell.run("wm density $d")
                p.edit().putBoolean("wm_applied", true).commit()
            }
        }
    }

    fun restore(ctx: Context) {
        val p = ctx.getSharedPreferences("gs", Context.MODE_PRIVATE)

        if (p.getBoolean("active", false)) {
            for (k in keys) {
                val parts = k.split(":")
                val v = p.getString("saved_$k", "null") ?: "null"
                if (v.startsWith("ERR")) continue
                if (v == "null" || v.isEmpty()) {
                    Shell.run("settings delete ${parts[0]} ${parts[1]}")
                } else {
                    Shell.run("settings put ${parts[0]} ${parts[1]} $v")
                }
            }
            p.edit().putBoolean("active", false).commit()
        }

        if (p.getBoolean("wm_applied", false)) {
            Shell.run("wm size reset")
            Shell.run("wm density reset")
            p.edit().putBoolean("wm_applied", false).commit()
        }
    }
}
