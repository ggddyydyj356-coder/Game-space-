package com.gamespace.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusView: TextView
    private lateinit var gamesBox: LinearLayout

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refresh() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("gs", MODE_PRIVATE)
        buildUi()
        try {
            Shizuku.addRequestPermissionResultListener(permListener)
        } catch (e: Throwable) {
            // ignore
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
        } catch (e: Throwable) {
            // ignore
        }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { onClick() }
        return b
    }

    private fun check(label: String, key: String, def: Boolean): CheckBox {
        val c = CheckBox(this)
        c.text = label
        c.isChecked = prefs.getBoolean(key, def)
        c.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply() }
        return c
    }

    private fun label(text: String, size: Float): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setPadding(0, dp(10), 0, dp(4))
        return t
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(24))
        scroll.addView(col)

        col.addView(label("Game Space", 28f))

        statusView = TextView(this)
        statusView.textSize = 14f
        col.addView(statusView)

        col.addView(button("1. Shizuku Permission Do") {
            if (!Shell.binderAlive()) {
                toast("Pehle Shizuku app kholo aur Start karo")
            } else if (!Shell.permitted()) {
                try {
                    Shizuku.requestPermission(100)
                } catch (e: Throwable) {
                    toast("Permission error: " + e.message)
                }
            } else {
                toast("Permission pehle se mili hui hai")
            }
        })

        col.addView(button("2. Overlay Permission Do") {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(i)
        })

        col.addView(label("Game start hone par ye karo:", 16f))
        col.addView(check("Do Not Disturb ON", "dnd", true))
        col.addView(check("Heads-up notifications band", "heads", true))
        col.addView(check("Animations tez (0.5x)", "anim", true))
        col.addView(check("Auto brightness band", "bright", true))
        col.addView(check("RAM clean (background apps)", "ram", true))

        val opts = listOf(100, 90, 80, 70, 60)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            opts.map { if (it == 100) "Resolution: Normal (100%)" else "Resolution: $it%" }
        )
        sp.setSelection(opts.indexOf(prefs.getInt("res", 100)).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                prefs.edit().putInt("res", opts[pos]).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        col.addView(sp)

        col.addView(label("Meri Games", 16f))
        col.addView(button("Games Chuno / Badlo") { pickGames() })

        gamesBox = LinearLayout(this)
        gamesBox.orientation = LinearLayout.VERTICAL
        col.addView(gamesBox)

        col.addView(label("Game ke baad", 16f))
        col.addView(button("Settings Wapas Normal Karo") {
            Thread {
                GameMode.restore(this)
                stopService(Intent(this, OverlayService::class.java))
                runOnUiThread { toast("Settings wapas normal ho gayi") }
            }.start()
        })

        col.addView(label("Note: Shizuku reboot ke baad dobara start karna padta hai.", 12f))

        setContentView(scroll)
    }

    private fun refresh() {
        val s = when {
            !Shell.binderAlive() -> "Shizuku: band hai (Shizuku app mein Start karo)"
            !Shell.permitted() -> "Shizuku: chal raha hai, permission baaki hai"
            else -> "Shizuku: ready"
        }
        val o = if (Settings.canDrawOverlays(this)) "Overlay: ready" else "Overlay: permission baaki hai"
        statusView.text = s + "\n" + o
        refreshGames()
    }

    private fun savedGames(): Set<String> = prefs.getStringSet("games", emptySet()) ?: emptySet()

    private fun refreshGames() {
        gamesBox.removeAllViews()
        for (pkg in savedGames()) {
            val name = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                continue
            }
            gamesBox.addView(button("PLAY  $name") { startGame(pkg) })
        }
    }

    private fun pickGames() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(packageManager).toString()) }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val names = apps.map { it.second }.toTypedArray()
        val current = savedGames()
        val checked = BooleanArray(apps.size) { current.contains(apps[it].first) }

        AlertDialog.Builder(this)
            .setTitle("Games chuno")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Save") { _, _ ->
                val set = HashSet<String>()
                for (i in apps.indices) {
                    if (checked[i]) set.add(apps[i].first)
                }
                prefs.edit().putStringSet("games", set).apply()
                refreshGames()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startGame(pkg: String) {
        if (!Shell.permitted()) {
            toast("Pehle Shizuku start karo aur permission do")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Pehle Overlay permission do")
            return
        }
        Thread {
            GameMode.apply(this)
            runOnUiThread {
                startForegroundService(Intent(this, OverlayService::class.java))
                val li = packageManager.getLaunchIntentForPackage(pkg)
                if (li != null) {
                    startActivity(li)
                } else {
                    toast("Game khul nahi saka")
                }
            }
        }.start()
    }
}
