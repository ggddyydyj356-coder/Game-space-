package com.gamespace.app

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Game ke upar floating "GS" button + panel (RAM, battery, ping, screenshot, record). */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private lateinit var panel: LinearLayout
    private lateinit var info: TextView
    private lateinit var recBtn: Button

    private val handler = Handler(Looper.getMainLooper())
    private var recording = false
    private var pingText = "--"

    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var moved = false

    private val ticker: Runnable = object : Runnable {
        override fun run() {
            updateInfo()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("gs", "Game Space", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "gs")
            .setContentTitle("Game Space chal raha hai")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        startForeground(1, n)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        val r = root
        if (r != null) {
            try {
                wm.removeView(r)
            } catch (e: Exception) {
                // ignore
            }
        }
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) {
        handler.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    private fun btn(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 12f
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildOverlay() {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL

        val bubble = TextView(this)
        bubble.text = "GS"
        bubble.setTextColor(Color.WHITE)
        bubble.gravity = Gravity.CENTER
        bubble.textSize = 14f
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(0xCC1E88E5.toInt())
        bubble.background = circle
        bubble.layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        container.addView(bubble)

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(10), dp(10), dp(10), dp(10))
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.RECTANGLE
        bg.cornerRadius = dp(10).toFloat()
        bg.setColor(0xE6212121.toInt())
        panel.background = bg
        panel.visibility = View.GONE

        info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.textSize = 12f
        info.text = "..."
        panel.addView(info)

        panel.addView(btn("RAM Clean") {
            Thread {
                Shell.run("am kill-all")
                toast("RAM clean ho gaya")
            }.start()
        })

        panel.addView(btn("Screenshot") {
            Thread {
                val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val path = "/sdcard/Pictures/GameSpace_$ts.png"
                Shell.run("mkdir -p /sdcard/Pictures")
                Shell.run("screencap -p $path")
                Shell.run("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://$path")
                toast("Screenshot save: Pictures/GameSpace_$ts.png")
            }.start()
        })

        recBtn = btn("Record Start") { toggleRecord() }
        panel.addView(recBtn)

        panel.addView(btn("Restore aur Band Karo") {
            Thread {
                if (recording) {
                    Shell.run("kill -2 \$(pidof screenrecord)")
                }
                GameMode.restore(this)
                handler.post { stopSelf() }
            }.start()
        })

        container.addView(panel)
        root = container

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = dp(120)

        bubble.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - touchX).toInt()
                    val dy = (ev.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(container, lp)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }

        wm.addView(container, lp)
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
            handler.removeCallbacks(ticker)
        } else {
            panel.visibility = View.VISIBLE
            handler.removeCallbacks(ticker)
            handler.post(ticker)
        }
    }

    private fun updateInfo() {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val freeMb = mi.availMem / 1048576L
        val totalMb = mi.totalMem / 1048576L

        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1

        info.text = "RAM free: $freeMb / $totalMb MB\nBattery: $pct%  |  $temp C\nPing: $pingText"

        Thread {
            var result = "--"
            try {
                val p = Runtime.getRuntime().exec(arrayOf("ping", "-c", "1", "-W", "1", "8.8.8.8"))
                val out = p.inputStream.bufferedReader().readText()
                p.waitFor()
                val m = Regex("time=([0-9.]+)").find(out)
                result = if (m != null) m.groupValues[1] + " ms" else "no net"
            } catch (e: Exception) {
                result = "--"
            }
            handler.post { pingText = result }
        }.start()
    }

    private fun toggleRecord() {
        if (!recording) {
            recording = true
            recBtn.text = "Record Stop"
            Thread {
                try {
                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    Shell.run("mkdir -p /sdcard/Movies")
                    toast("Recording shuru (max 3 min)")
                    val p = Shell.spawn("screenrecord --time-limit 180 /sdcard/Movies/GameSpace_$ts.mp4")
                    p.waitFor()
                    toast("Recording save: Movies/GameSpace_$ts.mp4")
                } catch (e: Throwable) {
                    toast("Recording fail: " + e.message)
                }
                handler.post {
                    recording = false
                    recBtn.text = "Record Start"
                }
            }.start()
        } else {
            Thread {
                Shell.run("kill -2 \$(pidof screenrecord)")
            }.start()
        }
    }
}
