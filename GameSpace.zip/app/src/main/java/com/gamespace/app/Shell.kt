package com.gamespace.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Shizuku ke through shell (adb level) commands chalata hai. */
object Shell {

    fun binderAlive(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun permitted(): Boolean = try {
        binderAlive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Shizuku API 13 mein newProcess private hai, isliye reflection se call karte hain. */
    fun spawn(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    fun run(cmd: String): String = try {
        val p = spawn(cmd)
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        (out + err).trim()
    } catch (e: Throwable) {
        "ERR: " + e.message
    }
}
